#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::MainWindow)
{
  ui->setupUi(this);
}

MainWindow::~MainWindow()
{
  delete ui;
}

void MainWindow::on_pushButton_clicked()
{
  QNetworkAccessManager *manager; // Менеджер по запросам к сети
  QNetworkRequest request; // Запрос
  QSslConfiguration sSlConfig; // SSL настройки

  // Задаем параметры для SSL
  sSlConfig.setDefaultConfiguration(QSslConfiguration::defaultConfiguration());
  sSlConfig.setProtocol(QSsl::TlsV1_2);
  request.setSslConfiguration(sSlConfig);

  // Если нужно, то разрешаем переходить по редиректам
  request.setAttribute(QNetworkRequest::FollowRedirectsAttribute, true);

  // Создаем экземпляр менеджера и связываем сигнал прихода ответа к какому-нибудь слоту
  manager = new QNetworkAccessManager(this);
  connect(manager, SIGNAL(finished(QNetworkReply*)),
          this, SLOT(replyFinished(QNetworkReply*)));

  // Задаем адрес нужной страницы
  request.setUrl(QUrl("https://www.google.com/"));

  // Отправляем запрос
  manager->get(request);
}

void MainWindow::replyFinished(QNetworkReply* reply) {
  if (reply->error() == QNetworkReply::NoError) {
    //Ответ от сервера приводим к строке
    QByteArray bytes = reply->readAll();
    QString html = QString::fromUtf8(bytes.data(), bytes.size());

    // Код ответа от сервера: 200, 404 и др.
    int statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    // С какого url нам пришел ответ
    QString url = reply->url().toString();

    // Используем полученные данные по своему усмотрению
    ui->textEdit->insertPlainText("statusCode = " + QString::number(statusCode) + "\n");
    ui->textEdit->insertPlainText("url = " + url + "\n");
    ui->textEdit->insertPlainText("html = " + html + "\n");
  } else {
    // Если что-то пошло не так, то обрабатываем ошибку как нам это нужно
    qDebug() << reply->errorString();
  }

  // Удаляем ответ от сервера
  reply->deleteLater();
}
